#JSON POST REQUEST
from doctest import debug
import logging
from flask import Flask, request
#from request_toolbelt.utils import dump
import gspread
import pandas as pd
from oauth2client.service_account import ServiceAccountCredentials
import os
import json
from pandas import json_normalize
import logging

#logging.basicConfig(level=logging.DEBUG)

scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('data-log-349319-182d1d00f309.json', scope)
client = gspread.authorize(creds)
sheet = client.open("Data-Log-MaskDetection")
sheet_instance = sheet.get_worksheet(0)

def convertion(json_data):
    df = pd.DataFrame.from_dict(json_data['array'])
    return df

app = Flask(__name__)

@app.route('/post_json', methods=['POST'])

def process_json():
    content_type = request.headers.get('Content-Type')

    #if (content_type == 'application/json'):
    json_data = request.get_json(force=True)
    sheet_instance.insert_rows(convertion(json_data).values.tolist())    
    return content_type

if __name__ == '__main__':
    app.run()
